<?php

return array( 
	'required'      => '字段 :label 必填.',
	'min_length'    => '字段 :label 至少 :param:1 长度.',
	'max_length'    => '字段 :label 至多 :param:1 长度.',
	'exact_length'  => '字段 :label 必须包含 :param:1 字符.',
	'match_value'   => '字段 :label 必须包含 :param:1.',
	'match_pattern' => '字段 :label 必须匹配模式 :param:1.',
	'match_field'   => '字段 :label 必须匹配字段 :param:1.',
	'valid_email'   => '字段 :label 必须包含一个有效的电子邮件地址.',
	'valid_emails'  => '字段 :label 必须包含一个有效的电子邮件地址的列表.',
	'valid_url'     => '字段 :label 必须包含一个有效的URL.',
	'valid_ip'      => '字段 :label 必须包含一个有效的IP地址.',
	'numeric_min'   => '最小的数值 :label 应该 :param:1',
	'numeric_max'   => '最大的数值 :label 应该 :param:1',
	'valid_string'  => '有效的字符串规则 :rule 未能对字段 :label',
);
