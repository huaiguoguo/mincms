<?php

return array(
	'previous' => '上一页',
	'next'     => '下一页',
);

